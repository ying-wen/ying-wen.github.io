# 强化学习独立教学实现

解压后在本目录运行。Python 3.10+；classic/continual标准库例子无需GPU。

```bash
python3 implementations/runtime.py --list
python3 implementations/classic/td_lambda.py --steps 1200 --seeds 0 1 2 3 4 --out results/MY_NEW_RUN
```

深度例子先在自己的隔离环境安装PyTorch：

```bash
python3 -m pip install -r examples/deep_requirements.txt
python3 implementations/deep/ppo.py --steps 1200 --seeds 0 1 2 3 4 --out results/PPO_NEW_RUN
```

[逐步阅读与运行](docs/learning-code.md) · [真实覆盖与缺口](docs/implementation-coverage.md) · [作者工程入口](docs/author-projects.md)

本包包含独立运行所需源码、共享依赖及配套机制实验测试。安装PyTorch后运行：

```bash
python3 -m unittest discover -s tests -p 'test_extended_*.py' -v
python3 -m unittest discover -s tests -p 'test_average_systems.py' -v
python3 -m unittest discover -s tests -p 'test_nonlinear_diagnostics.py' -v
python3 -m unittest discover -s tests -p 'test_streaming_composition.py' -v
python3 -m unittest discover -s tests -p 'test_integrated_agents.py' -v
python3 -m unittest discover -s tests -p 'test_reading_derivations.py' -v
python3 -m unittest discover -s tests -p 'test_learner_control.py' -v
```

测试检查更新公式、梯度、终止与数据边界；通过测试不表示原论文性能已经复现。完整教材与全仓检查请看教程仓库。
作者工程只提供固定源码获取工具与清单，未包含完整作者源码、checkpoint或训练成果。
教学曲线不构成一般算法效能或原论文重训证据；输出目录必须是新目录。
许可证索引见LICENSE；教学代码见LICENSE-CODE，文档见LICENSE-DOCS.md。
上游作者工程保留各自许可证。
